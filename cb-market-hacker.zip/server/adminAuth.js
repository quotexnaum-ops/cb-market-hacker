module.exports = function(req,res,next){
  const token = req.headers["x-admin"];
  if(token !== "CB_ADMIN_TOKEN") return res.status(403).json({error:"Unauthorized"});
  next();
}
