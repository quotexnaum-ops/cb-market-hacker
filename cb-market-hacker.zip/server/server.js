const express = require("express");
const axios = require("axios");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));

// ================= FILE STORAGE =================
const DB_DIR = path.join(__dirname, "db");
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR);

const LICENSE_FILE = path.join(DB_DIR, "licenses.json");
const MARKET_FILE = path.join(DB_DIR, "markets.json");

if (!fs.existsSync(LICENSE_FILE)) fs.writeFileSync(LICENSE_FILE, "[]");
if (!fs.existsSync(MARKET_FILE)) fs.writeFileSync(MARKET_FILE, "[]");

const readJSON = (file) => JSON.parse(fs.readFileSync(file));
const writeJSON = (file, data) =>
  fs.writeFileSync(file, JSON.stringify(data, null, 2));

// ================= ADMIN LOGIN =================
app.post("/api/admin/login", (req, res) => {
  const { user, pass } = req.body;
  if (user === "admin" && pass === "CB_ADMIN_123") {
    return res.json({ ok: true });
  }
  res.json({ ok: false });
});

// ================= LICENSE API =================

// CREATE LICENSE
app.post("/api/admin/license/create", (req, res) => {
  const { key, tier, days } = req.body;
  let list = readJSON(LICENSE_FILE);

  if (list.find((l) => l.key === key)) {
    return res.json({ error: "License exists" });
  }

  const exp = new Date(Date.now() + days * 86400000)
    .toISOString()
    .split("T")[0];

  list.push({
  key,
  tier,
  exp,
  usedToday: 0,
  lastDate: new Date().toISOString().split("T")[0]
});
  writeJSON(LICENSE_FILE, list);

  res.json({ ok: true });
});

// DELETE LICENSE
app.post("/api/admin/license/delete", (req, res) => {
  const { key } = req.body;
  let list = readJSON(LICENSE_FILE);
  list = list.filter((l) => l.key !== key);
  writeJSON(LICENSE_FILE, list);
  res.json({ ok: true });
});

// LIST LICENSE
app.get("/api/admin/license/list", (req, res) => {
  res.json(readJSON(LICENSE_FILE));
});

// ================= MARKET API =================

// ADD MARKET
app.post("/api/admin/market/add", (req, res) => {
  const { pair } = req.body;
  let list = readJSON(MARKET_FILE);

  if (!list.includes(pair)) {
    list.push(pair);
    writeJSON(MARKET_FILE, list);
  }
  res.json({ ok: true });
});

// DELETE MARKET
app.post("/api/admin/market/delete", (req, res) => {
  const { pair } = req.body;
  let list = readJSON(MARKET_FILE);
  list = list.filter((p) => p !== pair);
  writeJSON(MARKET_FILE, list);
  res.json({ ok: true });
});

// LIST MARKET
app.get("/api/admin/market/list", (req, res) => {
  res.json(readJSON(MARKET_FILE));
});

// ================= USER LOGIN (LICENSE CHECK) =================
app.post("/api/login", (req, res) => {
  const { key } = req.body;
  const list = readJSON(LICENSE_FILE);
  const lic = list.find((l) => l.key === key);

  if (!lic) return res.json({ ok: false });

  if (new Date(lic.exp) < new Date())
    return res.json({ ok: false, expired: true });

  res.json({
  ok: true,
  tier: lic.tier,
  key: lic.key
});
});

// ================= INDICATORS =================
function calculateEMA(prices, period) {
  const k = 2 / (period + 1);
  let ema = prices[0];
  let result = [];

  for (let i = 1; i < prices.length; i++) {
    ema = prices[i] * k + ema * (1 - k);
    result.push(ema);
  }
  return result;
}

function calculateRSI(prices, period = 14) {
  let gains = 0, losses = 0;

  for (let i = prices.length - period - 1; i < prices.length - 1; i++) {
    let diff = prices[i + 1] - prices[i];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }

  const rs = gains / (losses || 1);
  return 100 - 100 / (1 + rs);
}

// ================= REAL SIGNAL API =================
app.get("/api/real-signal", async (req, res) => {
  const licenseKey = req.headers["x-license"];
if (!licenseKey) return res.json({ error: true });

let licenses = readJSON(LICENSE_FILE);
let lic = licenses.find(l => l.key === licenseKey);

if (!lic) return res.json({ error: true });

const today = new Date().toISOString().split("T")[0];
if (lic.lastDate !== today) {
  lic.usedToday = 0;
  lic.lastDate = today;
}

const limits = {
  FREE: 2,
  PRO: 30,
  PRIME: Infinity
};

if (lic.usedToday >= limits[lic.tier]) {
  return res.json({ limit: true });
}
  const markets = readJSON(MARKET_FILE);
  if (!markets.length) return res.json({ error: true });

  const pair = req.query.pair || markets[Math.floor(Math.random() * markets.length)];
  const symbol = pair.replace("/", "");

  try {
    const url = `https://api.twelvedata.com/time_series?symbol=${symbol}&interval=1min&outputsize=50&apikey=3194f8c0872043048c9d07beb0ce0075`;
    const response = await axios.get(url);

    if (!response.data.values) return res.json({ error: true });

    const candles = response.data.values.reverse();
    const closes = candles.map(c => parseFloat(c.close));

    const ema10 = calculateEMA(closes, 10);
    const ema20 = calculateEMA(closes, 20);
    const rsi = calculateRSI(closes);

    let side = "WAIT";

    if (ema10.at(-1) > ema20.at(-1) && rsi < 70) side = "CALL";
    if (ema10.at(-1) < ema20.at(-1) && rsi > 30) side = "PUT";

    if (side === "WAIT") return res.json({ error: true });
    lic.usedToday += 1;
    writeJSON(LICENSE_FILE, licenses);

    res.json({
      pair: symbol,
      side,
      confidence: Math.floor(82 + Math.random() * 15),
      entry: new Date(Date.now() + 60000).toLocaleTimeString(),
      logic: "EMA 10 / EMA 20 + RSI"
    });

  } catch (err) {
    console.log("SIGNAL ERROR:", err.message);
    res.json({ error: true });
  }
});

// ================= START =================
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
